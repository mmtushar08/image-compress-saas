const express = require("express");
const cors = require("cors");
require("dotenv").config();
const path = require("path");

const compressRoutes = require("./routes/compress");

const app = express();

app.use(cors({
  exposedHeaders: ["X-Original-Size", "X-Compressed-Size", "X-Saved-Percent"]
}));
app.use(express.json());

// Simple in-memory rate limiter (resets on restart)
const usage = {}; // { ip: { count: 0, date: 'YYYY-MM-DD' } }

// Pro API Keys (in production, store in database)
const proApiKeys = new Set([
  'sk_live_demo_pro_key_12345',
  // Add more API keys here
]);

app.use((req, res, next) => {
  if (req.path.startsWith("/api/compress") && req.method === "POST") {
    // Check for API key in header
    const apiKey = req.headers['x-api-key'];

    // If valid Pro API key, skip rate limiting
    if (apiKey && proApiKeys.has(apiKey)) {
      req.isPro = true;
      return next();
    }

    // Free tier rate limiting
    const ip = req.ip;
    const today = new Date().toISOString().split("T")[0];

    if (!usage[ip]) {
      usage[ip] = { count: 0, date: today };
    }

    // Reset count if day changed
    if (usage[ip].date !== today) {
      usage[ip] = { count: 0, date: today };
    }

    if (usage[ip].count >= 20) {
      return res.status(429).json({ error: "Daily limit reached. Please upgrade to Pro." });
    }

    usage[ip].count++;
  }
  next();
});

app.use(express.static(path.join(__dirname, "../web")));
app.get("/api/check-limit", (req, res) => {
  // Check for API key
  const apiKey = req.headers['x-api-key'];

  if (apiKey && proApiKeys.has(apiKey)) {
    return res.json({ remaining: -1, plan: 'pro' }); // -1 means unlimited
  }

  const ip = req.ip;
  const today = new Date().toISOString().split("T")[0];
  const currentUsage = usage[ip];

  const remaining = currentUsage && currentUsage.date === today
    ? Math.max(0, 20 - currentUsage.count)
    : 20;

  res.json({ remaining, plan: 'free' });
});

app.use("/api/compress", compressRoutes);

// Global error handler (must be BEFORE listen)
app.use((err, req, res, next) => {
  if (err.message && err.message.includes("Only PNG and JPG")) {
    return res.status(400).json({ error: err.message });
  }

  console.error("Unhandled error:", err);
  res.status(500).json({ error: "Internal Server Error" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ API running on http://localhost:${PORT}`);
});
