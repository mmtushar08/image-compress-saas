export default function Footer() {
    return (
        <footer className="footer">
            <p>&copy; 2025 Smart Image Compression. Made with ❤️.</p>
        </footer>
    );
}
